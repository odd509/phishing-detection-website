import pandas as pd
import mailbox
from bs4 import BeautifulSoup


def parse_html(html_content):

    soup = BeautifulSoup(html_content, "lxml")
    inlines = soup.find_all(inline=True)

    for inline in inlines:
        if inline.name == "a":  # a hyperlink value
            inline.append(f"[URL: {inline.get('href')}]")
        inline.unwrap()

    soup = BeautifulSoup(str(soup), "lxml")
    output_string = soup.get_text("\n", strip=True)

    return output_string


def extract_email_body(message):
    body = ""
    if message.is_multipart():
        for part in message.walk():
            content_type = part.get_content_type()
            if content_type == "text/plain":
                body += parse_html(
                    part.get_payload(decode=True).decode("utf-8", errors="ignore")
                )
            elif content_type == "text/html":
                # Convert HTML to plain text
                body += parse_html(
                    part.get_payload(decode=True).decode("utf-8", errors="ignore")
                )
    else:
        body = parse_html(
            message.get_payload(decode=True).decode("utf-8", errors="ignore")
        )
    return body.strip()


def dataset_to_dataframe(dataset_path):
    # Load the mbox file
    mbox = mailbox.mbox(dataset_path)

    # Initialize lists to store data
    data = {"From": [], "Subject": [], "Date": [], "Body": []}

    # Iterate through each email in the mbox file
    _ = 0
    total = len(mbox)
    for message in mbox:

        # Extract relevant information
        sender = message["From"]
        subject = message["Subject"]
        date = message["Date"]
        body = extract_email_body(message)

        # Append data to lists
        data["From"].append(sender)
        data["Subject"].append(subject)
        data["Date"].append(date)
        data["Body"].append(body)
        _ += 1
        print(f"{_} / {total}", end="\r")
    # Create a Pandas DataFrame
    df = pd.DataFrame(data)

    return df
