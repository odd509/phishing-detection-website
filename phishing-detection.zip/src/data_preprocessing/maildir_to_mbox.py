import mailbox
import os
import glob


def maildir_to_mbox(mbox_output_path, mail_dir_pattern):
    if os.path.isfile(mbox_output_path):
        print("File already exists!")
        return

    # Use glob to find all subdirectories matching the pattern
    user_directories = glob.glob(mail_dir_pattern)
    all_files = []

    # Iterate through user directories and collect all files (excluding directories)
    for user_directory in user_directories:
        files_in_user_directory = [
            f
            for f in os.listdir(user_directory)
            if os.path.isfile(os.path.join(user_directory, f))
        ]
        all_files.extend(
            [os.path.join(user_directory, f) for f in files_in_user_directory]
        )

    # Create a new mbox file if there are messages to add
    if all_files:
        mbox = mailbox.mbox(mbox_output_path)

        # Iterate over selected files and add their content to the mbox
        _ = 0
        total = len(all_files)
        for file_path in all_files:
            with open(file_path, "rb") as maildir_file:
                message = mailbox.mboxMessage(maildir_file.read())
                mbox.add(message)
            _ += 1
            print(f"{_} / {total} mails", end="\r")
        # Close the mbox file
        mbox.close()
