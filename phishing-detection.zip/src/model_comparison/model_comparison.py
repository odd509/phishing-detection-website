import matplotlib.pyplot as plt


def compare_classification_reports(model_reports):
    """
    Visualizes the F1 scores of different machine learning models
    using a Matplotlib bar plot with a logarithmic scale.

    Parameters:
    - model_reports: List of tuples containing model names and
    their classification reports.
    """
    model_names = [model_name for model_name, _ in model_reports]
    f1_scores = [
        float(report["weighted avg"]["f1-score"]) for _, report in model_reports
    ]
    plt.figure(figsize=(10, len(model_reports) * 0.8))

    # Create a bar plot with a logarithmic scale for the y-axis
    plt.barh(
        model_names,
        f1_scores,
        color="mediumpurple",
        height=0.5,
        edgecolor="black",
        linewidth=1.2,
    )

    plt.xlabel("F1-Score")
    plt.title("Model Comparison - F1-Score")
    plt.show()

    plt.figure(figsize=(10, len(model_reports) * 0.8))

    plt.barh(
        model_names,
        f1_scores,
        color="mediumpurple",
        height=0.5,
        edgecolor="black",
        linewidth=1.2,
    )

    plt.xlabel("F1-Score (Logarithmic Scale)")
    plt.title("Model Comparison - F1-Score (Logarithmic Scale)")
    plt.xscale("log")  # Set logarithmic scale for the x-axis
    plt.show()


def compare_accuracy(model_reports):
    model_names = [model_name for model_name, _ in model_reports]
    accuracies = [
        float(report["accuracy"]) for _, report in model_reports
    ]
    
    # Extract model names and accuracy scores for plotting

    # Normal Scale
    plt.figure(figsize=(10, 6))
    plt.barh(
        model_names,
        accuracies,
        color="mediumpurple",
        height=0.5,
        edgecolor="black",
        linewidth=1.2,
    )
    plt.xlabel("Models")
    plt.ylabel("Accuracy Score")
    plt.title("Model Accuracy Comparison")
    # plt.ylim(0.9, 1.0)  # Set y-axis limits for better visualization
    plt.show()

    # Logarithmic scale
    plt.figure(figsize=(10, 6))
    plt.barh(
        model_names,
        accuracies,
        color="mediumpurple",
        height=0.5,
        edgecolor="black",
        linewidth=1.2,
    )
    plt.xlabel("Models")
    plt.ylabel("Accuracy Score (Logarithmic Scale)")
    plt.title("Model Accuracy Comparison (Logarithmic Scale)")
    # plt.ylim(0.9, 1.0)  # Set y-axis limits for better visualization
    plt.xscale("log")  # Set logarithmic scale for the x-axis

    plt.show()
