from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import cross_val_score
from sklearn.svm import SVC
from sklearn.pipeline import make_pipeline
import numpy as np


def vectorize(data):
    # Concatenate "Subject" and "Body" fields into a single text
    combined_text = data["Subject"] + " " + data["Body"]

    # Initialize TF-IDF Vectorizer
    tfidf_vectorizer = TfidfVectorizer(ngram_range=(1, 2), max_features=5000)

    # Fit and transform preprocessed text data
    tfidf_features = tfidf_vectorizer.fit_transform(combined_text)
    return tfidf_features, tfidf_vectorizer


def cross_validation(data):

    X = data["Subject"] + " " + data["Body"]
    y = data["isPhishing"]

    ngram_ranges = [(1, 1), (1, 2), (1, 3), (2, 2), (2, 3)]

    # Perform cross-validation for each combination of parameters
    for ngram_range in ngram_ranges:
        # Create a pipeline
        model = make_pipeline(
            TfidfVectorizer(ngram_range=ngram_range),
            SVC(kernel="linear"),
        )

        # Perform cross-validation
        scores = cross_val_score(model, X, y, cv=5, scoring="f1")

        # Print the results
        print(
            f"ngram_range={ngram_range}: "
            f"Mean f1 score: {np.mean(scores):.4f} (+/- {np.std(scores):.4f})"
        )
