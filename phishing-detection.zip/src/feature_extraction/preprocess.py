import string
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import nltk
import re
import uuid
from nltk.probability import FreqDist
import matplotlib.pyplot as plt

# from nltk.stem import PorterStemmer


nltk.download("punkt")
nltk.download("stopwords")
nltk.download("wordnet")


def preprocess_text(text):
    # Tokenization
    tokens = word_tokenize(text)

    # Lowercasing
    tokens = [word.lower() for word in tokens]

    # Removing punctuation
    table = str.maketrans("", "", string.punctuation)
    stripped = [word.translate(table) for word in tokens]

    # Removing non-alphabetic tokens
    words = [word for word in stripped if word.isalpha()]

    # Removing stopwords
    stop_words = set(stopwords.words("english"))
    words = [word for word in words if word not in stop_words]

    # Stemming and Lemmatization
    # stemmer = PorterStemmer()
    # stemmed = [stemmer.stem(word) for word in words]
    lemmatizer = WordNetLemmatizer()

    lemmatized = [lemmatizer.lemmatize(word) for word in words]

    return " ".join(lemmatized)


def get_tokens(data):
    # Separate the data based on the classification
    phishing_data = data[data["isPhishing"] == 1]
    legit_data = data[data["isPhishing"] == 0]

    # Concatenate all phishing and non-phishing text data
    phishing_text_data = " ".join(phishing_data["Body"] + phishing_data["Subject"])
    legit_text_data = " ".join(legit_data["Body"] + legit_data["Subject"])

    # Tokenize the text
    phishing_tokens = word_tokenize(phishing_text_data)
    legit_tokens = word_tokenize(legit_text_data)

    return phishing_tokens, legit_tokens


def plot_most_common_tokens(data):
    phishing_tokens, legit_tokens = get_tokens(data)

    # Calculate token frequency
    phish_freq_dist = FreqDist(phishing_tokens)
    legit_freq_dist = FreqDist(legit_tokens)

    # Plot the frequency distributions
    phish_freq_dist.plot(20, title="Phishing Tokens", color="red")
    legit_freq_dist.plot(20, title="Legit Tokens", color="green")

    plt.show()


def plot_combined_percentage(data):
    phishing_tokens, legit_tokens = get_tokens(data)

    phishing_freq_dist = FreqDist(phishing_tokens)
    legit_freq_dist = FreqDist(legit_tokens)

    # Get the top 20 most common tokens in phishing and legitimate datasets
    top_phishing_tokens = phishing_freq_dist.most_common(20)
    top_legit_tokens = legit_freq_dist.most_common(20)

    print("Most common 50 tokens for:")
    print("Phishing", phishing_freq_dist.most_common(50))
    print("Legit", legit_freq_dist.most_common(50))

    # Plot for Phishing dataset
    labels_phishing = [token for token, count in top_phishing_tokens]
    counts_phishing = [
        count / len(phishing_tokens) * 100 for token, count in top_phishing_tokens
    ]

    plt.bar(labels_phishing, counts_phishing, color="red", alpha=0.7, label="Phishing")

    plt.xticks(rotation=45, ha="right")
    plt.title("Top 20 Tokens Percentage Comparison - Phishing")
    plt.ylabel("Percentage")
    plt.legend()
    plt.tight_layout()
    plt.show()

    # Plot for Legitimate dataset
    labels_legit = [token for token, count in top_legit_tokens]
    counts_legit = [
        count / len(legit_tokens) * 100 for token, count in top_legit_tokens
    ]

    plt.bar(labels_legit, counts_legit, color="green", alpha=0.7, label="Legitimate")

    plt.xticks(rotation=45, ha="right")
    plt.title("Top 20 Tokens Percentage Comparison - Legitimate")
    plt.ylabel("Percentage")
    plt.legend()
    plt.tight_layout()
    plt.show()


def plot_most_common_unique_tokens(data):
    phishing_tokens, legit_tokens = get_tokens(data)

    # Find words unique to each dataset
    phishing_unique_words = set(phishing_tokens) - set(legit_tokens)
    legit_unique_words = set(legit_tokens) - set(phishing_tokens)

    # Calculate token frequency
    phish_freq_dist = FreqDist(phishing_tokens)
    legit_freq_dist = FreqDist(legit_tokens)

    # Extract frequencies for unique words
    phish_unique_freqs = {word: phish_freq_dist[word] for word in phishing_unique_words}
    legit_unique_freqs = {word: legit_freq_dist[word] for word in legit_unique_words}

    # Plot the frequency distributions
    FreqDist(phish_unique_freqs).plot(20, title="Unique Phishing Tokens", color="red")
    FreqDist(legit_unique_freqs).plot(20, title="Unique Legit Tokens", color="green")

    plt.show()


def obfuscate_and_filter_tokens(text):
    """
    Obfuscates tokens for enhanced model accuracy by replacing emails with UUIDs,
    reducing repetitive emails in datasets. Common words unique to a single dataset
    are also filtered.

    Args:
        tokens (list):  List of tokens to be obfuscated.

    Returns:
        list: Obfuscated tokens.
    """

    tokens = word_tokenize(text)

    # Email obfuscation
    email_regex = r"\b[A-Za-z0-9._%+-]+@([A-Za-z0-9.-]+\.[A-Za-z]{2,})\b"
    tokens = [
        re.sub(email_regex, f"{uuid.uuid4().hex}@foo.bar", token) for token in tokens
    ]

    # Word filtration
    filtered_words = [
        "enroncom",
        "enron",
        "monkeyorg",
        "jose",
        "usaa",
        "corp",
        "hotmailcom",
        "aolcom",
        "yahoocom",
    ]

    tokens = [token for token in tokens if token.lower() not in filtered_words]

    return " ".join(tokens)
