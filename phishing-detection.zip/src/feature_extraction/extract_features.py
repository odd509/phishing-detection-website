def extract_domain_features(email_text):
    phishing_keywords = [
        "account",
        "verification",
        "suspended",
        "update",
        "security",
        "alert",
        "password",
        "reset",
        "expiration",
        "bank",
        "credit card",
        "payment",
        "billing",
        "verify",
        "limited time",
        "special offer",
        "free gift",
        "prize",
        "unauthorized",
        "compromised",
        "notice",
        "support",
        "click",
        "click here",
        "download",
        "open this link",
    ]
    domain_features = {}

    for keyword in phishing_keywords:
        domain_features[f"keyword_{keyword}"] = email_text.count(keyword)

    return domain_features
