import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix


def plot_confusion_matrix(model, y_test, y_pred):
    """
    Plots the confusion matrix for a given machine learning model.

    Parameters:
    - model: The trained machine learning model.
    - X_test: The test features.
    - y_test: The true labels for the test set.
    - class_labels: Optional. List of class labels for better visualization.
    """
    # Compute the confusion matrix
    cm = confusion_matrix(y_test, y_pred)

    # Create a heatmap for visualization
    plt.figure(figsize=(8, 6))
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        xticklabels=["Legitimate", "Phishing"],
        yticklabels=["Legitimate", "Phishing"],
    )

    plt.title(f"{type(model).__name__} Confusion Matrix")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.show()


