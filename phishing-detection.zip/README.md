# Phishing Detection

Create the virtual environment
```
python -m venv venv
```
Activate the virtual env and install the requirements
-   For Linux
```
source venv/bin/activate
pip install -r requirements.txt
```
*   For Windows
```
.\venv\Scripts\activate
pip install -r requirements.txt
```